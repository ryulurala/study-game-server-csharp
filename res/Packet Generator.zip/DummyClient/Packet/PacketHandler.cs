﻿using ServerCore;
using System;
using System.Collections.Generic;
using System.Text;

class PacketHandler
{
	public static void S_TestHandler(PacketSession session, IPacket packet)
	{

	}
}
